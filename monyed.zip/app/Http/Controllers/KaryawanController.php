<?php

namespace App\Http\Controllers;

use App\Models\Karyawan;
use App\Http\Requests\StoreKaryawanRequest;
use App\Http\Requests\UpdateKaryawanRequest;
use Illuminate\Http\Request;
use App\Enums\RoleEnum;
use Illuminate\Support\Facades\Route;

class KaryawanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $karyawans = Karyawan::where('jabatan', '!=', 'Manager HRD')
                             ->get();
        return view('hrd.karyawans.index', compact('karyawans'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $roles = collect(RoleEnum::cases())
                    ->whereNotIn('value', [RoleEnum::SuperAdmin->value, RoleEnum::HRD->value])
                    ->pluck('value', 'value');
        return view('hrd.karyawans.create', compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreKaryawanRequest $request)
    {
        Karyawan::create($request->validated());

        return redirect()->route('karyawans.index')->with('success', 'Karyawan berhasil ditambahkan.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Karyawan $karyawan)
    {
        return view('hrd.karyawans.show', compact('karyawan'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Karyawan $karyawan)
    {
        $roles = collect(RoleEnum::cases())
                    ->whereNotIn('value', [RoleEnum::SuperAdmin->value, RoleEnum::HRD->value])
                    ->pluck('value', 'value');
        return view('hrd.karyawans.edit', compact('karyawan', 'roles'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateKaryawanRequest $request, Karyawan $karyawan)
    {
        $karyawan->update($request->validated());

        return redirect()->route('karyawans.index')->with('success', 'Karyawan berhasil diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Karyawan $karyawan)
    {
        $karyawan->delete();
        return redirect()->route('hrd.data-karyawan.index')->with('success', 'Karyawan berhasil dihapus.');
    }
}
