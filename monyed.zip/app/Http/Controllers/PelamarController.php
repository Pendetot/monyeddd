<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\Pelamar\StorePelamarRequest;
use App\Http\Requests\Pelamar\UpdatePelamarRequest;
use App\Models\Pelamar;
use Illuminate\Http\Request;

class PelamarController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $pelamars = Pelamar::all();
        return view('hrd.pelamars.index', compact('pelamars'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('hrd.pelamars.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePelamarRequest $request)
    {
        Pelamar::create($request->validated());
        return redirect()->route('hrd.administrasi-pelamar.index')->with('success', 'Pelamar berhasil ditambahkan!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Pelamar $pelamar)
    {
        return view('hrd.pelamars.show', compact('pelamar'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Pelamar $pelamar)
    {
        return view('hrd.pelamars.edit', compact('pelamar'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePelamarRequest $request, Pelamar $pelamar)
    {
        $pelamar->update($request->validated());
        return redirect()->route('hrd.administrasi-pelamar.index')->with('success', 'Pelamar berhasil diperbarui!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pelamar $pelamar)
    {
        $pelamar->delete();
        return redirect()->route('hrd.administrasi-pelamar.index')->with('success', 'Pelamar berhasil dihapus!');
    }

    public function storeFromWizard(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'nik' => 'required|string|max:255',
            'no_kk' => 'required|string|max:255',
            'alamat' => 'required|string',
            'telepon' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'pengalaman' => 'required|string',
            'foto_formal' => 'required|file|mimes:jpg,jpeg,png',
            'penempatan' => 'required|string|max:255',
            'nama_pt' => 'required|string|max:255',
            'ijazah_sma' => 'required|file|mimes:pdf,jpg,jpeg,png',
            'ijazah_gp' => 'nullable|file|mimes:pdf,jpg,jpeg,png',
            'sertifikat_lsp' => 'nullable|file|mimes:pdf,jpg,jpeg,png',
        ]);

        $fotoFormalPath = $request->file('foto_formal')->store('public/foto_formal');
        $ijazahSmaPath = $request->file('ijazah_sma')->store('public/ijazah_sma');
        $ijazahGpPath = $request->hasFile('ijazah_gp') ? $request->file('ijazah_gp')->store('public/ijazah_gp') : null;
        $sertifikatLspPath = $request->hasFile('sertifikat_lsp') ? $request->file('sertifikat_lsp')->store('public/sertifikat_lsp') : null;

        Pelamar::create([
            'nama' => $validated['nama'],
            'nik' => $validated['nik'],
            'no_kk' => $validated['no_kk'],
            'alamat' => $validated['alamat'],
            'telepon' => $validated['telepon'],
            'email' => $validated['email'],
            'pengalaman' => $validated['pengalaman'],
            'foto_formal' => $fotoFormalPath,
            'penempatan' => $validated['penempatan'],
            'nama_pt' => $validated['nama_pt'],
            'ijazah_sma' => $ijazahSmaPath,
            'ijazah_gp' => $ijazahGpPath,
            'sertifikat_lsp' => $sertifikatLspPath,
        ]);

        return redirect()->route('welcome')->with('success', 'Data Anda telah berhasil dikirim.');
    }
}
