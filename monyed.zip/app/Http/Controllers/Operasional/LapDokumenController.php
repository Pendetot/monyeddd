<?php

namespace App\Http\Controllers\Operasional;

use App\Http\Controllers\Controller;

use App\Models\LapDokumen;
use Illuminate\Http\Request;

class LapDokumenController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $lapDokumens = LapDokumen::all();
        return view('operasional.lap_dokumen.index', compact('lapDokumens'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('operasional.lap_dokumen.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama_dokumen' => 'required|string|max:255',
            'jenis_dokumen' => 'required|string|max:255',
            'tanggal_upload' => 'required|date',
            'file_path' => 'required|string|max:255',
        ]);

        LapDokumen::create($request->all());

        return redirect()->route('operasional.lap-dokumen.index')->with('success', 'Laporan Dokumen berhasil ditambahkan.');
    }

    /**
     * Display the specified resource.
     */
    public function show(LapDokumen $lapDokumen)
    {
        return view('operasional.lap_dokumen.show', compact('lapDokumen'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(LapDokumen $lapDokumen)
    {
        return view('operasional.lap_dokumen.edit', compact('lapDokumen'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, LapDokumen $lapDokumen)
    {
        $request->validate([
            'nama_dokumen' => 'required|string|max:255',
            'jenis_dokumen' => 'required|string|max:255',
            'tanggal_upload' => 'required|date',
            'file_path' => 'required|string|max:255',
        ]);

        $lapDokumen->update($request->all());

        return redirect()->route('operasional.lap-dokumen.index')->with('success', 'Laporan Dokumen berhasil diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(LapDokumen $lapDokumen)
    {
        $lapDokumen->delete();
        return redirect()->route('operasional.lap-dokumen.index')->with('success', 'Laporan Dokumen berhasil dihapus.');
    }
}
