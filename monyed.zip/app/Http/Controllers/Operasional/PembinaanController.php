<?php

namespace App\Http\Controllers\Operasional;

use App\Http\Controllers\Controller;

use App\Models\Pembinaan;
use Illuminate\Http\Request;

class PembinaanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $pembinaans = Pembinaan::all();
        return view('operasional.pembinaan.index', compact('pembinaans'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('operasional.pembinaan.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'karyawan_id' => 'required|exists:karyawans,id',
            'tanggal_pembinaan' => 'required|date',
            'deskripsi' => 'required|string',
            'hasil' => 'required|string',
        ]);

        Pembinaan::create($request->all());

        return redirect()->route('operasional.pembinaan.index')->with('success', 'Pembinaan berhasil ditambahkan.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Pembinaan $pembinaan)
    {
        return view('operasional.pembinaan.show', compact('pembinaan'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Pembinaan $pembinaan)
    {
        return view('operasional.pembinaan.edit', compact('pembinaan'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pembinaan $pembinaan)
    {
        $request->validate([
            'karyawan_id' => 'required|exists:karyawans,id',
            'tanggal_pembinaan' => 'required|date',
            'deskripsi' => 'required|string',
            'hasil' => 'required|string',
        ]);

        $pembinaan->update($request->all());

        return redirect()->route('operasional.pembinaan.index')->with('success', 'Pembinaan berhasil diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pembinaan $pembinaan)
    {
        $pembinaan->delete();
        return redirect()->route('operasional.pembinaan.index')->with('success', 'Pembinaan berhasil dihapus.');
    }
}
