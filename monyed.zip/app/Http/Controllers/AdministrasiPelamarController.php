<?php

namespace App\Http\Controllers;

use App\Models\AdministrasiPelamar;
use Illuminate\Http\Request;

use App\Models\Pelamar;
use Illuminate\Http\Request;

class AdministrasiPelamarController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $pelamars = Pelamar::all();
        return view('hrd.administrasipelamar.index', compact('pelamars'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('hrd.administrasipelamar.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'email' => 'required|email|unique:pelamars,email',
            'telepon' => 'required|string|max:20',
            'alamat' => 'nullable|string',
            'tanggal_lahir' => 'required|date',
            'jenis_kelamin' => 'required|in:Laki-laki,Perempuan',
            'pendidikan_terakhir' => 'nullable|string|max:255',
            'pengalaman_kerja' => 'nullable|string',
            'posisi_dilamar' => 'required|string|max:255',
            'status_lamaran' => 'required|in:Diterima,Ditolak,Pending',
        ]);

        Pelamar::create($request->all());

        return redirect()->route('hrd.administrasi-pelamar.index')->with('success', 'Pelamar berhasil ditambahkan!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Pelamar $administrasiPelamar)
    {
        return view('hrd.administrasipelamar.show', ['pelamar' => $administrasiPelamar]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Pelamar $administrasiPelamar)
    {
        return view('hrd.administrasipelamar.edit', ['pelamar' => $administrasiPelamar]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pelamar $administrasiPelamar)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'email' => 'required|email|unique:pelamars,email,' . $administrasiPelamar->id,
            'telepon' => 'required|string|max:20',
            'alamat' => 'nullable|string',
            'tanggal_lahir' => 'required|date',
            'jenis_kelamin' => 'required|in:Laki-laki,Perempuan',
            'pendidikan_terakhir' => 'nullable|string|max:255',
            'pengalaman_kerja' => 'nullable|string',
            'posisi_dilamar' => 'required|string|max:255',
            'status_lamaran' => 'required|in:Diterima,Ditolak,Pending',
        ]);

        $administrasiPelamar->update($request->all());

        return redirect()->route('hrd.administrasi-pelamar.index')->with('success', 'Pelamar berhasil diperbarui!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pelamar $administrasiPelamar)
    {
        $administrasiPelamar->delete();
        return redirect()->route('hrd.administrasi-pelamar.index')->with('success', 'Pelamar berhasil dihapus!');
    }
}
