<?php

namespace App\Enums;

enum RoleEnum: string
{
    case SuperAdmin = 'superadmin';
    case HRD = 'hrd';
    case Keuangan = 'keuangan';
    case Operasional = 'operasional';
    case Pelamar = 'pelamar';
    case Guard = 'guard';
}
