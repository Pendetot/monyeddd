<?php

namespace App\Enums;

enum StatusCutiEnum: string
{
    case Pending = 'pending';
    case Disetujui = 'disetujui';
    case Ditolak = 'ditolak';
}