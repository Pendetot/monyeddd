<?php

namespace App\Enums;

enum JenisCutiEnum: string
{
    case Tahunan = 'tahunan';
    case Sakit = 'sakit';
    case Melahirkan = 'melahirkan';
    case Penting = 'penting';
}