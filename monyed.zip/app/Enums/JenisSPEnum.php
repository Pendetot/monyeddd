<?php

namespace App\Enums;

enum JenisSPEnum: string
{
    case SP1 = 'SP1';
    case SP2 = 'SP2';
    case SP3 = 'SP3';
}