<?php

namespace App\Enums;

enum AsalHutangEnum: string
{
    case SP = 'sp';
    case Pinjaman = 'pinjaman';
    case SuratPeringatan = 'surat_peringatan';
}