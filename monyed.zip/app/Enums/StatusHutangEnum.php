<?php

namespace App\Enums;

enum StatusHutangEnum: string
{
    case Lunas = 'lunas';
    case BelumLunas = 'belum_lunas';
}