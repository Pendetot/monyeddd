<?php

namespace App\Enums;

enum StatusKaryawanEnum: string
{
    case Aktif = 'aktif';
    case Nonaktif = 'nonaktif';
}