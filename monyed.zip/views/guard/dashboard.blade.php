@extends('layouts.app')

@section('title', 'Guard Dashboard')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Selamat Datang di Dashboard Guard</h3>
                </div>
                <div class="card-body">
                    <p>Ini adalah dashboard khusus untuk peran Guard.</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection