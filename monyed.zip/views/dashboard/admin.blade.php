@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">Dashboard Admin</div>
            <div class="card-body">
                Selamat datang, Admin! Ini adalah dashboard khusus untuk Anda.
                <!-- Tambahkan konten spesifik admin di sini -->
            </div>
        </div>
    </div>
</div>
@endsection
