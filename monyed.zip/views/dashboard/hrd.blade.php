@extends('layouts.app')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">Dashboard HRD</div>
            <div class="card-body">
                Selamat datang, HRD! Ini adalah dashboard khusus untuk Anda.
                <!-- Tambahkan konten spesifik HRD di sini -->
            </div>
        </div>
    </div>
</div>
@endsection
