<!DOCTYPE html>
<html lang="en">

<head>
    <title>Form Pelamar</title>
    <!-- [Meta] -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description"
        content="Light Able admin and dashboard template offer a variety of UI elements and pages, ensuring your admin panel is both fast and effective.">
    <meta name="author" content="phoenixcoded">

    <!-- [Favicon] icon -->
    <link rel="icon" href="{{ URL::asset('build/images/favicon.svg') }}" type="image/x-icon" />
    <!-- [Google Font : Public Sans] icon -->
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <!-- [phosphor Icons] https://phosphoricons.com/ -->
    <link rel="stylesheet" href="{{ URL::asset('build/fonts/phosphor/duotone/style.css') }}" />
    <!-- [Tabler Icons] https://tablericons.com -->
    <link rel="stylesheet" href="{{ URL::asset('build/fonts/tabler-icons.min.css') }}">
    <!-- [Feather Icons] https://feathericons.com -->
    <link rel="stylesheet" href="{{ URL::asset('build/fonts/feather.css') }}">
    <!-- [Font Awesome Icons] https://fontawesome.com/icons -->
    <link rel="stylesheet" href="{{ URL::asset('build/fonts/fontawesome.css') }}">
    <!-- [Material Icons] https://fonts.google.com/icons -->
    <link rel="stylesheet" href="{{ URL::asset('build/fonts/material.css') }}">
    <!-- [Template CSS Files] -->
    <link rel="stylesheet" href="{{ URL::asset('build/css/style.css') }}" id="main-style-link">
    <link rel="stylesheet" href="{{ URL::asset('build/css/style-preset.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('build/css/landing.css') }}">
</head>

<body data-pc-preset="preset-1" data-pc-sidebar-caption="true" data-pc-direction="ltr" data-pc-theme="light"
    class="landing-page">
    <!-- [ Main Content ] start -->
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>
    <!-- [ Pre-loader ] End -->

    <!-- [ Header ] start -->
    <header id="home">
        <nav class="navbar navbar-expand-md navbar-light default">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="{{ URL::asset('build/images/logo-dark.svg') }}" alt="logo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-center">
                        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- [ Header ] End -->

    <div class="container">
        <div class="row justify-content-center">
             @if(session('success'))
                <div class="col-md-8 text-center">
                    <div class="card mt-5">
                        <div class="card-body">
                            <i class="ph-duotone ph-check-circle f-50 text-success"></i>
                            <h3 class="mt-4 mb-3">Terima Kasih!</h3>
                            <p class="text-muted">{{ session('success') }}</p>
                        </div>
                    </div>
                </div>
            @else
            <div class="col-sm-12">
                <div id="basicwizard" class="form-wizard row justify-content-center">
                    <div class="col-sm-12 col-md-8 col-xxl-6 text-center">
                        <h3>Formulir Pendaftaran Pelamar</h3>
                        <p class="text-muted mb-4">Silakan isi data diri Anda dengan lengkap dan benar.</p>
                    </div>
                    <div class="col-12">
                        <form id="wizardForm" method="post" action="{{ route('pelamar.store.wizard') }}" enctype="multipart/form-data" class="needs-validation" novalidate>
                            @csrf
                            <div class="card">
                                <div class="card-body p-3">
                                    <ul class="nav nav-pills nav-justified">
                                        <li class="nav-item">
                                            <a href="#pelamar-data" data-bs-toggle="tab" data-toggle="tab" class="nav-link active">
                                                <i class="ph-duotone ph-user-circle"></i>
                                                <span class="d-none d-sm-inline">Form Pelamar</span>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#administrasi-data" data-bs-toggle="tab" data-toggle="tab" class="nav-link icon-btn">
                                                <i class="ph-duotone ph-file-text"></i>
                                                <span class="d-none d-sm-inline">Form Administrasi</span>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="#finish" data-bs-toggle="tab" data-toggle="tab" class="nav-link icon-btn">
                                                <i class="ph-duotone ph-check-circle"></i>
                                                <span class="d-none d-sm-inline">Selesai</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                    <div class="tab-content">
                                        <div id="bar" class="progress mb-3" style="height: 7px">
                                            <div class="bar progress-bar progress-bar-striped progress-bar-animated bg-success"></div>
                                        </div>
                                        <div class="tab-pane show active" id="pelamar-data">
                                            <div class="row">
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">Nama</label><input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" required /></div></div>
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">Alamat</label><input type="text" name="alamat" class="form-control" placeholder="Alamat Lengkap" required /></div></div>
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">NIK</label><input type="text" name="nik" class="form-control" placeholder="Nomor Induk Kependudukan" required /></div></div>
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">No Tlp WA (aktif)</label><input type="text" name="telepon" class="form-control" placeholder="Nomor Telepon WhatsApp Aktif" required /></div></div>
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" placeholder="Alamat Email" required /></div></div>
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">No KK</label><input type="text" name="no_kk" class="form-control" placeholder="Nomor Kartu Keluarga" required /></div></div>
                                                <div class="col-sm-12"><div class="mb-3"><label class="form-label">Pengalaman</label><textarea name="pengalaman" class="form-control" rows="3" placeholder="Jelaskan pengalaman kerja Anda" required></textarea></div></div>
                                                <div class="col-sm-12"><div class="mb-3"><label class="form-label">Foto Formal</label><input type="file" name="foto_formal" class="form-control" required /></div></div>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="administrasi-data">
                                            <div class="row">
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">Pilih Penempatan</label><select name="penempatan" class="form-select" required><option value="">Pilih...</option><option>Jakarta</option><option>Bandung</option><option>Surabaya</option></select></div></div>
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">Nama PT</label><input type="text" name="nama_pt" class="form-control" placeholder="Nama Perusahaan" required /></div></div>
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">Melampirkan Ijazah SMA</label><input type="file" name="ijazah_sma" class="form-control" required /></div></div>
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">Melampirkan Ijazah GP (jika ada)</label><input type="file" name="ijazah_gp" class="form-control" /></div></div>
                                                <div class="col-sm-6"><div class="mb-3"><label class="form-label">Sertifikat LSP</label><input type="file" name="sertifikat_lsp" class="form-control" /></div></div>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="finish">
                                            <div class="row d-flex justify-content-center">
                                                <div class="col-lg-6">
                                                    <div class="text-center">
                                                        <i class="ph-duotone ph-check-circle f-50 text-success"></i>
                                                        <h3 class="mt-4 mb-3">Selesai!</h3>
                                                        <p class="text-muted">Klik tombol "Daftar" untuk mengirimkan data Anda.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex wizard justify-content-between flex-wrap gap-2 mt-3">
                                    <div class="first">
                                        <a href="javascript:void(0);" class="btn btn-secondary">First</a>
                                    </div>
                                    <div class="d-flex">
                                        <div class="previous me-2">
                                            <a href="javascript:void(0);" class="btn btn-secondary">Sebelumnya</a>
                                        </div>
                                        <div class="next">
                                            <a href="javascript:void(0);" class="btn btn-secondary">Selanjutnya</a>
                                        </div>
                                    </div>
                                    <div class="last">
                                        <button type="submit" class="btn btn-primary">Daftar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>

    <!-- [ Footer ] start -->
    <footer class="footer">
        <div class="container">
            <div class="row align-items-center">
                <div class="col my-1">
                    <p class="m-0">Made with &#9829; by Team <a href="https://phoenixcoded.net/" target="_blank"> Phoenixcoded</a></p>
                </div>
            </div>
        </div>
    </footer>
    <!-- [ Footer ] end -->

    <!-- Required Js -->
    <script src="{{ URL::asset('build/js/plugins/popper.min.js') }}"></script>
    <script src="{{ URL::asset('build/js/plugins/simplebar.min.js') }}"></script>
    <script src="{{ URL::asset('build/js/plugins/bootstrap.min.js') }}"></script>
    <script src="{{ URL::asset('build/js/script.js') }}"></script>
    <script src="{{ URL::asset('build/js/plugins/wizard.min.js') }}"></script>
    <script>
        new Wizard("#basicwizard", {
            validate: true,
            progress: true
        });
    </script>
</body>

</html>