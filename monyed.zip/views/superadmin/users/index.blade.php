@extends('layouts.app')

@section('title', 'Manajemen Pengguna - ' . ucfirst($role))

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Daftar Pengguna {{ ucfirst($role) }}</h5>
                <div class="card-header-right">
                    <a href="{{ route('superadmin.users.create', ['role' => $role]) }}" class="btn btn-primary btn-sm">
                        <i class="feather icon-plus"></i> Tambah Pengguna {{ ucfirst($role) }}
                    </a>
                </div>
            </div>
            <div class="card-body">
                @if (session('success'))
                    <div class="alert alert-success" role="alert">
                        {{ session('success') }}
                    </div>
                @endif

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($users as $user)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $user->name }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>{{ $user->role->value }}</td>
                                    <td>
                                        <a href="{{ route('superadmin.users.edit', $user->id) }}" class="btn btn-icon btn-warning">
                                            <i class="feather icon-edit"></i>
                                        </a>
                                        <form action="{{ route('superadmin.users.destroy', $user->id) }}" method="POST" style="display: inline-block;">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-icon btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                                <i class="feather icon-trash-2"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection