
@include('layouts.loader')
@include('layouts.sidebar-detached')
@include('layouts.topbar-detached')
