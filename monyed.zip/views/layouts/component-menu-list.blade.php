<div class="offcanvas-xl offcanvas-start component-offcanvas" tabindex="-1" id="offcanvas_component">
  <div class="offcanvas-header">
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#offcanvas_component" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body p-0">
    <div class="card component-list-card position-xl-fixed">
      <div class="card-header">
        <div class="form-search">
          <i class="ph-duotone ph-magnifying-glass icon-search"></i>
          <input type="search" class="form-control" placeholder="Search Components" id="compo-menu-search" >
        </div>
      </div>
      <div class="card-body p-0">
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><h5 class="mt-3">Basic Components</h5></li>
          <li><a href="#" class="list-group-item list-group-item-action">All</a></li>
          <li><a href="/elements/bc_alert" class="list-group-item list-group-item-action">Alert</a></li>
          <li><a href="/elements/bc_button" class="list-group-item list-group-item-action">Button</a></li>
          <li><a href="/elements/bc_badges" class="list-group-item list-group-item-action">Badges</a></li>
          <li><a href="/elements/bc_breadcrumb" class="list-group-item list-group-item-action">Breadcrumb</a></li>
          <li><a href="/elements/bc_card" class="list-group-item list-group-item-action">Cards</a></li>
          <li><a href="/elements/bc_color" class="list-group-item list-group-item-action">Color</a></li>
          <li><a href="/elements/bc_collapse" class="list-group-item list-group-item-action">Collapse</a></li>
          <li><a href="/elements/bc_carousel" class="list-group-item list-group-item-action">Carousel</a></li>
          <li><a href="/elements/bc_dropdowns" class="list-group-item list-group-item-action">Dropdowns</a></li>
          <li><a href="/elements/bc_offcanvas" class="list-group-item list-group-item-action">Offcanvas</a></li>
          <li><a href="/elements/bc_pagination" class="list-group-item list-group-item-action">Pagination</a></li>
          <li><a href="/elements/bc_progress" class="list-group-item list-group-item-action">Progress</a></li>
          <li><a href="/elements/bc_list-group" class="list-group-item list-group-item-action">List group</a></li>
          <li><a href="/elements/bc_modal" class="list-group-item list-group-item-action">Modal</a></li>
          <li><a href="/elements/bc_spinner" class="list-group-item list-group-item-action">Spinner</a></li>
          <li><a href="/elements/bc_tabs" class="list-group-item list-group-item-action">Tabs & pills</a></li>
          <li><a href="/elements/bc_tooltip-popover" class="list-group-item list-group-item-action">Tooltip</a></li>
          <li><a href="/elements/bc_toasts" class="list-group-item list-group-item-action">Toasts</a></li>
          <li><a href="/elements/bc_typography" class="list-group-item list-group-item-action">Typography</a></li>
          <li><a href="/elements/bc_extra" class="list-group-item list-group-item-action">Other</a></li>
          <li class="list-group-item"><h5 class="mt-3">Advance Components</h5></li>
          <li><a href="/elements/ac_alert" class="list-group-item list-group-item-action">Sweet alert</a></li>
          <li><a href="/elements/ac_datepicker-component" class="list-group-item list-group-item-action">Datepicker</a></li>
          <li><a href="/elements/ac_lightbox" class="list-group-item list-group-item-action">Lightbox</a></li>
          <li><a href="/elements/ac_modal" class="list-group-item list-group-item-action">Modal</a></li>
          <li><a href="/elements/ac_notification" class="list-group-item list-group-item-action">Notification</a></li>
          <li><a href="/elements/ac_rangeslider" class="list-group-item list-group-item-action">Rangeslider</a></li>
          <li><a href="/elements/ac_slider" class="list-group-item list-group-item-action">Slider</a></li>
          <li><a href="/elements/ac_syntax_highlighter" class="list-group-item list-group-item-action">Syntax Highlighter</a></li>
          <li><a href="/elements/ac_tour" class="list-group-item list-group-item-action">Tour</a></li>
          <li><a href="/elements/ac_treeview" class="list-group-item list-group-item-action">Tree view</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
